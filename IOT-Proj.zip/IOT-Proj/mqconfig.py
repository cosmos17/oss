'''
Created on 2020. 5. 29.

@author: cskim
'''
mq_host = '121.133.116.239'
mq_user = 'rpi'
mq_password = 'hufs'
mq_title = 'cpu/temp'
